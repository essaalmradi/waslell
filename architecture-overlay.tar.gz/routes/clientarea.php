<?php

// Compatibility route file. Canonical definition lives in routes/api/clientarea.php.
require __DIR__ . '/api/clientarea.php';
