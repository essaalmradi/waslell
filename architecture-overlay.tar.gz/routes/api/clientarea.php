<?php

use App\Http\Controllers\ApiAuthController;
use App\Http\Controllers\Client\DeliveryManParcelsController;
use App\Http\Controllers\Client\ParcelController;
use App\Http\Controllers\Client\ProductsController;
use App\Http\Controllers\Client\StoreReceiptsController;
use App\Http\Controllers\Client\TasksController;
use Illuminate\Support\Facades\Route;

Route::get('/branches', [ApiAuthController::class, 'branches']);
Route::post('/login', [ApiAuthController::class, 'login'])->middleware('throttle:auth-login');
Route::post('/register', [ApiAuthController::class, 'register']);

Route::group(['middleware' => ['auth:sanctum']], function () {
    Route::post('/set-token', [ApiAuthController::class, 'set_token']);
    Route::post('/send-notification', [ApiAuthController::class, 'send_notification']);
    Route::post('/delete-account', [ApiAuthController::class, 'delete_account']);
    Route::get('/summary', [ParcelController::class, 'summary']);
    Route::get('/user', [ParcelController::class, 'user']);
    Route::get('/statuses', [ParcelController::class, 'statuses']);

    Route::group(['prefix' => 'receipts'], function () {
        Route::get('/', [StoreReceiptsController::class, 'index']);
        Route::get('/{id}', [StoreReceiptsController::class, 'show']);
    });
    Route::post('/collect/store', [ParcelController::class, 'collect_store']);

    Route::group(['prefix' => 'parcels'], function () {
        Route::get('/', [ParcelController::class, 'index']);
        Route::get('/recipient-history-stats', [ParcelController::class, 'recipient_history_stats']);
        Route::post('/list', [ParcelController::class, 'list']);
        Route::post('/store', [ParcelController::class, 'store']);
        Route::post('/{parcel}/update', [ParcelController::class, 'update']);
        Route::delete('/{parcel}/destroy', [ParcelController::class, 'destroy']);
        Route::get('/{parcel}/return', [ParcelController::class, 'return_parcel']);
        Route::get('/{id}', [ParcelController::class, 'show']);
        Route::post('/{id}/update-price', [ParcelController::class, 'update_price']);
    });
    Route::resource('products', ProductsController::class);
    Route::group(['prefix' => 'prices'], function () {
        Route::get('/', [ParcelController::class, 'prices']);
    });

    Route::group(['prefix' => 'tasks'], function () {
        Route::get('/', [TasksController::class, 'index']);
        Route::post('/store', [TasksController::class, 'store']);
    });
});

Route::group(['middleware' => ['auth:sanctum']], function () {


    Route::group(['prefix' => 'delivery-man'], function () {
        Route::get('/', [DeliveryManParcelsController::class, 'index']);
        Route::get('/parcels', [DeliveryManParcelsController::class, 'parcels']);
        Route::post('/partial-delivery', [DeliveryManParcelsController::class, 'partial_delivery']);
        Route::post('/parcels/make-call', [DeliveryManParcelsController::class, 'make_call']);

        Route::post('/parcels/multi-change-status', [DeliveryManParcelsController::class, 'multi_change_status']);
        Route::get('/statuses', [DeliveryManParcelsController::class, 'statuses']);
    });
});
