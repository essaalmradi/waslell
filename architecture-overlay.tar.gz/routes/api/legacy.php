<?php

use App\Http\Controllers\Client\ApiController;
use App\Http\Controllers\DeliveryCollectionsReceipt;
use App\Http\Controllers\DeliveryMan\DeliveryManHomeController;
use App\Http\Controllers\DeliveryReceiptReturn;
use App\Http\Controllers\PublicApiController;
use App\Http\Controllers\Store\StoreCollectionController;
use App\Http\Controllers\Store\StoreProductsController;
use App\Http\Controllers\StoreReceiptReturn;
use App\Http\Controllers\User\BranchFlightController;
use App\Http\Controllers\User\CollectionsController;
use App\Http\Controllers\User\DeliveryReceiptsCash;
use App\Http\Controllers\User\DeliveryReceiptController;
use App\Http\Controllers\User\FlightsController;
use App\Http\Controllers\User\ParcelsController;
use App\Http\Controllers\User\ReceiptsController;
use App\Http\Controllers\User\StoreReceiptRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'persons', 'middleware' => ['auth:sanctum']], function () {
    Route::get('/parcels', [DeliveryManHomeController::class, 'get_parcels_data']);
    Route::get('/flights/{id}/show', [DeliveryManHomeController::class, 'get_flight_data']);
    Route::get('/collections-flight/{id}/show', [DeliveryManHomeController::class, 'get_collections_flight_data']);
    Route::post('/collections/change-status', [DeliveryManHomeController::class, 'change_status']);
    Route::post('/parcels/change-status', [ParcelsController::class, 'change_status']);
    Route::get('/parcels/{id}/change-status', [ParcelsController::class, 'change_status_one']);
    Route::get('/parcels/get-cities', [ParcelsController::class, 'get_cities']);
    Route::post('/parcels/partial-receipt', [ParcelsController::class, 'partial_receipt']);
    Route::get('/parcels/get-under-preparation', [StoreCollectionController::class, 'get_parcels']);
    Route::post('/parcels/multiple-store', [ParcelsController::class, 'multiple_store']);

    Route::get('/products/init', [StoreProductsController::class, 'init']);

});
Route::group(['prefix' => 'shipping-system', 'middleware' => ['auth:sanctum']], function () {
    Route::group(['prefix' => 'parcels'], function () {
        Route::get('/', [ParcelsController::class, 'api_index']);
        Route::get('/inventory', [ParcelsController::class, 'api_inventory']);
        Route::post('/inventory/commit', [ParcelsController::class, 'inventory_commit']);
        Route::get('/charts', [ParcelsController::class, 'get_charts']);
        Route::post('/get-specific', [ParcelsController::class, 'get_specific']);
        Route::post('/update-price', [ParcelsController::class, 'update_price']);
        Route::post('/delete/all', [ParcelsController::class, 'delete_all']);
        Route::post('/change-status', [ParcelsController::class, 'change_status']);
        Route::get('/{id}/change-status', [ParcelsController::class, 'change_status_one']);
        Route::get('/{id}/delete', [ParcelsController::class, 'destroy']);
        Route::get('/{id}/re-charging', [ParcelsController::class, 're_charging']);
        Route::get('/{id}/paid', [ParcelsController::class, 'paid_parcel_one']);
        Route::get('/{id}/records', [ParcelsController::class, 'get_parcel_records']);
        Route::get('/get-cities', [ParcelsController::class, 'get_cities']);
        Route::get('/get-destinations', [ParcelsController::class, 'get_destinations']);
        Route::get('/get-records', [ParcelsController::class, 'get_records']);
        Route::get('/clear-records', [ParcelsController::class, 'clear_records']);
        Route::get('/seen-records', [ParcelsController::class, 'seen_records']);
        Route::get('/get-stores', [ParcelsController::class, 'get_stores']);
        Route::get('/get-branches', [ParcelsController::class, 'get_branches']);
        Route::post('/paid-all', [ParcelsController::class, 'paid_parcel']);
        Route::post('/multiple-store', [ParcelsController::class, 'multiple_store']);
    });
    Route::group(['prefix' => 'branch-flights'], function () {
        Route::get('/init', [BranchFlightController::class, 'get_init_data']);
        Route::post('/store', [BranchFlightController::class, 'store']);
    });
    Route::group(['prefix' => 'collections'], function () {
        Route::get('/', [CollectionsController::class, 'api_index']);
        Route::post('/get-specific', [CollectionsController::class, 'get_specific']);
        Route::get('/get-new', [CollectionsController::class, 'get_new_collections']);
        Route::get('/{id}/delete', [CollectionsController::class, 'destroy']);
        Route::post('/delete/all', [CollectionsController::class, 'destroy_all']);
        Route::post('/{id}/update-price', [CollectionsController::class, 'update_price']);
        Route::post('/flights/store', [CollectionsController::class, 'flight_store']);
    });
    Route::group(['prefix' => 'flights'], function () {
        Route::get('/init', [FlightsController::class, 'get_init_data']);
        Route::get('/cities', [FlightsController::class, 'get_flights_cities']);
        Route::post('/store', [FlightsController::class, 'store']);
        Route::post('/get-parcel', [FlightsController::class, 'get_parcel']);
        Route::post('/{id}/update', [FlightsController::class, 'update']);
        Route::post('/delete/all', [FlightsController::class, 'delete_all']);
        Route::get('/{id}', [FlightsController::class, 'get_flight_data']);
        Route::get('/{id}/delete', [FlightsController::class, 'delete_flight_parcel']);
    });
    Route::group(['prefix' => 'receipts'], function () {
        Route::get('/get-recipient', [ReceiptsController::class, 'get_recipient']);
        Route::post('/store', [ReceiptsController::class, 'store']);
        Route::post('/stores/store', [ReceiptsController::class, 'stores_store']);
        // Route::post('/stores/{id}/update', [ReceiptsController::class, 'update_store']);
        Route::get('{id}/get-parcels', [ReceiptsController::class, 'get_parcels']);
        Route::get('{id}/get-store', [ReceiptsController::class, 'get_store_data']);
        Route::get('/{id}/get-delivered-parcels', [ReceiptsController::class, 'get_delivered_parcels']);
    });
    Route::group(['prefix' => 'requests'], function () {
        Route::get('/{id}/get-parcels', [StoreReceiptRequest::class, 'get_parcels']);
        Route::post('/stores/store', [StoreReceiptRequest::class, 'stores_store']);
        Route::post('/stores/store-all', [StoreReceiptRequest::class, 'stores_store_all']);
        Route::get('{id}/get-store', [StoreReceiptRequest::class, 'get_store_data']);
        Route::post('/stores/{id}/update', [StoreReceiptRequest::class, 'update_store']);
    });
    Route::group(['prefix' => 'returns'], function () {
        Route::get('/{id}/get-parcels', [StoreReceiptReturn::class, 'get_parcels']);
        Route::post('/stores/store', [StoreReceiptReturn::class, 'stores_store']);
        Route::get('{id}/get-store', [StoreReceiptReturn::class, 'get_store_data']);
        Route::post('/stores/{id}/update', [StoreReceiptReturn::class, 'update_store']);
    });
    Route::group(['prefix' => 'delivery'], function () {
        Route::get('/', [DeliveryReceiptReturn::class, 'get_delivery_mens']);
        Route::get('/get-flights', [DeliveryReceiptReturn::class, 'get_flights']);
        Route::get('/{id}/transcations', [DeliveryManHomeController::class, 'get_transcations']);
        Route::get('/get-collections-flights', [DeliveryCollectionsReceipt::class, 'get_flights']);
        Route::get('/collections/flights/{id}/get-collections', [DeliveryCollectionsReceipt::class, 'get_collections']);
        Route::post('/collections/flights/receipt/store', [DeliveryCollectionsReceipt::class, 'receipts_store']);
        Route::get('/{id}/get-parcels', [DeliveryReceiptReturn::class, 'get_parcels']);
        Route::post('/returns/store', [DeliveryReceiptReturn::class, 'returns_store']);

        Route::get('/receipts/{id}/get-parcels', [DeliveryReceiptController::class, 'get_parcels']);
        Route::post('/receipts/store', [DeliveryReceiptController::class, 'receipts_store']);

        Route::get('/receipts-cash/{id}/get-parcels', [DeliveryReceiptsCash::class, 'get_parcels']);
        Route::post('/receipts-cash/store', [DeliveryReceiptsCash::class, 'cashs_store']);
        Route::post('/{id}/search', [DeliveryManHomeController::class, 'search']);
    });
});
Route::group(['prefix' => 'public'], function () {
    Route::get('/prices', [PublicApiController::class, 'prices']);
});

Route::group(['prefix' => 'client', 'middleware' => ['auth:sanctum']], function () {
    Route::get('/get-city-price', [ApiController::class, 'get_city_price']);
    Route::post('/parcels/store', [ApiController::class, 'store_parcel']);
});

