<?php

use App\Modules\Identity\Http\Controllers\ApiAuthController;
use Illuminate\Support\Facades\Route;

Route::post('/login', [ApiAuthController::class, 'login'])->middleware('throttle:auth-login');

Route::middleware(['auth:sanctum', 'actor.active'])->group(function () {
    Route::get('/me', [ApiAuthController::class, 'me']);
    Route::post('/logout', [ApiAuthController::class, 'logout']);
    Route::post('/refresh', [ApiAuthController::class, 'refresh']);
});
