<?php

use Illuminate\Support\Facades\Route;

Route::prefix('auth')->name('auth.')->group(base_path('routes/api/v1/auth.php'));
