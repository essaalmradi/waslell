<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\UsersController as AdminUsersController;
use App\Http\Controllers\CollectionFlightController;
use App\Http\Controllers\CronJob\BackupController;
use App\Http\Controllers\DeliveryCollectionsReceipt;
use App\Http\Controllers\DeliveryMan\DeliveryManHomeController;
use App\Http\Controllers\DeliveryMan\DeliveryManReportsController;
use App\Http\Controllers\DeliveryReceiptReturn;
use App\Http\Controllers\PersonsController;
use App\Http\Controllers\Store\StoreCollectionController;
use App\Http\Controllers\Store\StoreHomeController;
use App\Http\Controllers\Store\StoreReportsController;
use App\Http\Controllers\StoreParcelsController;
use App\Http\Controllers\StoreReceiptReturn;
use App\Http\Controllers\User\BranchesController;
use App\Http\Controllers\User\BranchFlightController;
use App\Http\Controllers\User\BranchSettlementsController;
use App\Http\Controllers\User\ParcelsController as UserParcelsController;
use App\Http\Controllers\User\HomeController as UserHomeController;
use App\Http\Controllers\User\StoresController as UserStoresController;
use App\Http\Controllers\User\DeliveryMenController;
use App\Http\Controllers\User\CitiesController;
use App\Http\Controllers\User\CollectionsController;
use App\Http\Controllers\User\CustodyController;
use App\Http\Controllers\User\DeliveryReceiptController;
use App\Http\Controllers\User\DeliveryReceiptsCash;
use App\Http\Controllers\User\DestinationsController;
use App\Http\Controllers\User\EmployeeTransactionsController;
use App\Http\Controllers\User\FlightsController;
use App\Http\Controllers\User\GalleriesController;
use App\Http\Controllers\User\InOfficeDeliveryController;
use App\Http\Controllers\User\MoneyTransfersController;
use App\Http\Controllers\User\PayrollsController;
use App\Http\Controllers\User\ReceiptsController;
use App\Http\Controllers\User\SalariesController;
use App\Http\Controllers\User\StoreCitiesController;
use App\Http\Controllers\User\StoreReceiptRequest;
use App\Http\Controllers\User\StoreReceiptsController;
use App\Http\Controllers\User\StoreTransactionsController;
use App\Http\Controllers\User\TasksController as UserTasksController;
use App\Http\Controllers\Transfers\TransfersHubController;
use App\Http\Controllers\Transfers\InternalTransferChatController;
use App\Http\Controllers\Transfers\ExternalTransferChatController;
use App\Http\Controllers\Transfers\TransferPriceListController;
use App\Http\Controllers\Transfers\TransfersBranchVisibilityController;
use App\Http\Controllers\User\TransactionController;
use App\Http\Controllers\User\TransferSettlementsController;
use App\Http\Controllers\User\TreasuryController;
use App\Http\Controllers\User\SystemSettingsController;
use App\Http\Controllers\User\UsersController;
use App\Http\Controllers\VisitorController;
use App\Http\Controllers\Warehouse\ProductsController;
use App\Models\City;
use App\Models\MainCity;
use App\Models\Parcel;
use App\Models\Store;

Auth::routes([
    'register' => false, // Registration Routes...
    'reset' => false, // Password Reset Routes...
    'verify' => false, // Email Verification Routes...
]);


Route::redirect('/', '/persons/login');
Route::get('/backup', [BackupController::class, 'download'])->middleware('auth_admin');
Route::get('/tracking', [VisitorController::class, 'tracking']);

Route::get('/set-main-cities', function () {
    $cities = City::all();
    $not_found = '';
    foreach ($cities as $city) {
        $main_city = MainCity::where('name', 'LIKE', '%' . $city->name . '%')->orderByDesc('id')->first();
        if ($main_city) {
            $city->main_city_id =  $main_city->id;
            $city->save();
        } else {
            $not_found .= '<br/> ' . $city->name;
        }
    }
})->middleware('auth_admin');


Route::get('/create-storage-link', function () {
    Artisan::call('storage:link');
    return 'Storage link created successfully.';
})->middleware('auth_admin');


Route::get('/make-backu454p23454', function () {
    $origin_cities = City::where('branch_id', 1)->where('parent_city_id',null)->get();
    foreach ($origin_cities as $city1) {
        $city = new City();
        $city->name = $city1->name;
        $city->branch_id = 5;
        $city->price = $city1->price;
        $city->delivery_man_price = $city1->delivery_man_price;
        $city->region = $city1->region;
        $city->main_city_id = $city1->main_city_id;
        $city->days = $city1->days;
        $city->save();
    }
})->middleware('auth_admin');

