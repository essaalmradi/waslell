<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\UsersController as AdminUsersController;
use App\Http\Controllers\CollectionFlightController;
use App\Http\Controllers\CronJob\BackupController;
use App\Http\Controllers\DeliveryCollectionsReceipt;
use App\Http\Controllers\DeliveryMan\DeliveryManHomeController;
use App\Http\Controllers\DeliveryMan\DeliveryManReportsController;
use App\Http\Controllers\DeliveryReceiptReturn;
use App\Http\Controllers\PersonsController;
use App\Http\Controllers\Store\StoreCollectionController;
use App\Http\Controllers\Store\StoreHomeController;
use App\Http\Controllers\Store\StoreReportsController;
use App\Http\Controllers\StoreParcelsController;
use App\Http\Controllers\StoreReceiptReturn;
use App\Http\Controllers\User\BranchesController;
use App\Http\Controllers\User\BranchFlightController;
use App\Http\Controllers\User\BranchSettlementsController;
use App\Http\Controllers\User\ParcelsController as UserParcelsController;
use App\Http\Controllers\User\HomeController as UserHomeController;
use App\Http\Controllers\User\StoresController as UserStoresController;
use App\Http\Controllers\User\DeliveryMenController;
use App\Http\Controllers\User\CitiesController;
use App\Http\Controllers\User\CollectionsController;
use App\Http\Controllers\User\CustodyController;
use App\Http\Controllers\User\DeliveryReceiptController;
use App\Http\Controllers\User\DeliveryReceiptsCash;
use App\Http\Controllers\User\DestinationsController;
use App\Http\Controllers\User\EmployeeTransactionsController;
use App\Http\Controllers\User\FlightsController;
use App\Http\Controllers\User\GalleriesController;
use App\Http\Controllers\User\InOfficeDeliveryController;
use App\Http\Controllers\User\MoneyTransfersController;
use App\Http\Controllers\User\PayrollsController;
use App\Http\Controllers\User\ReceiptsController;
use App\Http\Controllers\User\SalariesController;
use App\Http\Controllers\User\StoreCitiesController;
use App\Http\Controllers\User\StoreReceiptRequest;
use App\Http\Controllers\User\StoreReceiptsController;
use App\Http\Controllers\User\StoreTransactionsController;
use App\Http\Controllers\User\TasksController as UserTasksController;
use App\Http\Controllers\Transfers\TransfersHubController;
use App\Http\Controllers\Transfers\InternalTransferChatController;
use App\Http\Controllers\Transfers\ExternalTransferChatController;
use App\Http\Controllers\Transfers\TransferPriceListController;
use App\Http\Controllers\Transfers\TransfersBranchVisibilityController;
use App\Http\Controllers\User\TransactionController;
use App\Http\Controllers\User\TransferSettlementsController;
use App\Http\Controllers\User\TreasuryController;
use App\Http\Controllers\User\SystemSettingsController;
use App\Http\Controllers\User\UsersController;
use App\Http\Controllers\VisitorController;
use App\Http\Controllers\Warehouse\ProductsController;
use App\Models\City;
use App\Models\MainCity;
use App\Models\Parcel;
use App\Models\Store;

Route::get('/logout', [UserHomeController::class, 'logout']);
Route::group(['prefix' => 'shipping-system', 'middleware' => ['auth', 'auth.active']], function () {
    Route::get('/', [UserHomeController::class, 'index']);
    Route::get('/unable-delivery', [UserParcelsController::class, 'unable_delivery']);
    Route::post('/unable-delivery', [UserParcelsController::class, 'unable_delivery_store']);
    
    Route::get('/prepaid', [UserParcelsController::class, 'prepaid']);
    Route::get('/to-branch', [UserHomeController::class, 'to_branch']);
    Route::get('/due-shipping-system', [UserHomeController::class, 'due_shipping_system']);
    Route::get('/due-shipping-system/reset', [UserHomeController::class, 'due_shipping_system_reset']);
    Route::get('/testing', [UserHomeController::class, 'testing']);
    Route::get('/account', [UserHomeController::class, 'edit_account']);
    Route::post('/account/update', [UserHomeController::class, 'edit_update']);
    Route::group(['prefix' => 'stores'], function () {
        Route::get('/', [UserStoresController::class, 'index']);
        Route::middleware(['auth.rule:stores_create'])->group(function () {
            Route::get('/new', [UserStoresController::class, 'create']);
            Route::post('/store', [UserStoresController::class, 'store']);
            Route::get('/{id}/active', [UserStoresController::class, 'active']);
        });
        Route::middleware(['auth.rule:stores_edit'])->group(function () {
            Route::get('/{id}/edit', [UserStoresController::class, 'edit']);
            Route::post('/{id}/update', [UserStoresController::class, 'update']);
        });
        Route::middleware(['auth.rule:stores_delete'])->group(function () {
            Route::get('/{id}/delete', [UserStoresController::class, 'destroy']);
        });

        Route::get('/{id}/show', [UserStoresController::class, 'show']);
        Route::get('/{id}/print', [UserStoresController::class, 'print_store']);
        Route::get('/{id}/print/terms', [UserStoresController::class, 'print_store_terms']);
    });
    Route::group(['prefix' => 'delivery-men'], function () {
        Route::get('/', [DeliveryMenController::class, 'index']);
        Route::get('/dues', [DeliveryMenController::class, 'dues']);

        Route::middleware(['auth.rule:deliveryman_create'])->group(function () {
            Route::get('/new', [DeliveryMenController::class, 'create']);
            Route::post('/store', [DeliveryMenController::class, 'store']);
        });
        Route::middleware(['auth.rule:deliveryman_edit'])->group(function () {
            Route::get('/{id}/edit', [DeliveryMenController::class, 'edit']);
            Route::post('/{id}/update', [DeliveryMenController::class, 'update']);
        });
        Route::middleware(['auth.rule:deliveryman_delete'])->group(function () {
            Route::get('/{id}/delete', [DeliveryMenController::class, 'destroy']);
        });
        Route::get('/{id}/parcels', [DeliveryMenController::class, 'parcels']);
        Route::get('/{id}/print', [DeliveryMenController::class, 'print_data']);

        Route::get('/reports/create', [DeliveryMenController::class, 'reports_create']);
        Route::get('/reports', [DeliveryMenController::class, 'reports_show']);
    });
    Route::group(['prefix' => 'deliveryman-cash'], function () {
        Route::get('/', [DeliveryMenController::class, 'receipts_cash_index']);
        Route::middleware(['auth.rule:deliveryman_receipts_show'])->group(function () {
            Route::get('/new', [DeliveryMenController::class, 'receipts_cash_create']);
            Route::post('/store', [DeliveryMenController::class, 'receipts_cash_store']);
        });
        Route::middleware(['auth.rule:deliveryman_receipts_create'])->group(function () {
            Route::post('/{id}/update', [DeliveryMenController::class, 'receipts_cash_update']);
            Route::get('/{id}/edit', [DeliveryMenController::class, 'receipts_cash_edit']);
        });
        Route::middleware(['auth.rule:deliveryman_receipts_delete'])->group(function () {
            Route::get('/{id}/delete', [DeliveryMenController::class, 'receipts_cash_delete']);
        });
    });
    Route::group(['prefix' => 'cities'], function () {
        Route::get('/', [CitiesController::class, 'index']);
        Route::get('/print', [CitiesController::class, 'print']);
        Route::middleware(['auth.rule:cities_create'])->group(function () {
            Route::get('/new', [CitiesController::class, 'create']);
            Route::post('/store', [CitiesController::class, 'store']);
        });
        Route::middleware(['auth.rule:cities_edit'])->group(function () {
            Route::get('/{id}/edit', [CitiesController::class, 'edit']);
            Route::post('/{id}/update', [CitiesController::class, 'update']);
        });
        Route::middleware(['auth.rule:cities_delete'])->group(function () {
            Route::get('/{id}/delete', [CitiesController::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'parcels'], function () {
        Route::get('/total-receivable', [UserParcelsController::class, 'total_receivable']);
        Route::middleware(['auth.rule:parcels_create'])->group(function () {
            Route::get('/new', [UserParcelsController::class, 'create']);
            Route::get('/recipient-history-stats', [UserParcelsController::class, 'recipient_history_stats']);
            Route::get('/rechange', [UserParcelsController::class, 'rechange']);
            Route::post('/store', [UserParcelsController::class, 'store']);
            Route::get('/multiple-create', [UserParcelsController::class, 'multiple_create']);
            Route::get('/import', [UserParcelsController::class, 'import']);
            Route::post('/import', [UserParcelsController::class, 'import_store']);
        });
        Route::middleware(['auth.rule:parcels_show'])->group(function () {
            Route::get('/', [UserParcelsController::class, 'index']);
            Route::get('/inventory', [UserParcelsController::class, 'inventory']);
            Route::get('/delayed-in-branch', [UserParcelsController::class, 'delayed_in_branch']);
            Route::get('/records', [UserParcelsController::class, 'records']);
            Route::get('/deleted', [UserParcelsController::class, 'deleted']);
            Route::post('/print', [UserParcelsController::class, 'print']);
            Route::get('/print-list', [UserParcelsController::class, 'print']);
            Route::get('/{id}/print', [UserParcelsController::class, 'print_one']);
            Route::get('/{id}/show', [UserParcelsController::class, 'show']);
            Route::get('/search', [UserParcelsController::class, 'search']);
            Route::get('/multiple-print', [UserParcelsController::class, 'multiple_print']);
        });
        Route::middleware(['auth.rule:parcels_edit'])->group(function () {
            Route::get('/{id}/edit', [UserParcelsController::class, 'edit']);
        });
        Route::middleware(['auth.rule:parcels_edit'])->group(function () {
            Route::post('/{id}/update', [UserParcelsController::class, 'update']);
        });
        Route::middleware(['auth.rule:parcels_delete'])->group(function () {
            Route::get('/{id}/delete', [UserParcelsController::class, 'destroy']);
        });

        Route::middleware(['auth.rule:parcels_delete', 'auth.rule:parcels_edit'])->group(function () {
            Route::get('/parcels-report', [UserParcelsController::class, 'parcels_report']);
        });
        Route::middleware(['auth.rule:administrative_modification'])->group(function () {
            Route::get('/administrative-modification', [UserParcelsController::class, 'administrative_modification']);
            Route::post('/administrative-modification', [UserParcelsController::class, 'administrative_modification_store']);
        });
    });
    Route::group(['prefix' => 'destinations'], function () {
        Route::get('/', [DestinationsController::class, 'index']);
        Route::middleware(['auth.rule:destinations_create'])->group(function () {
            Route::get('/new', [DestinationsController::class, 'create']);
            Route::post('/store', [DestinationsController::class, 'store']);
        });

        Route::middleware(['auth.rule:destinations_edit'])->group(function () {
            Route::get('/{id}/edit', [DestinationsController::class, 'edit']);
            Route::post('/{id}/update', [DestinationsController::class, 'update']);
        });
        Route::middleware(['auth.rule:destinations_delete'])->group(function () {
            Route::get('/{id}/delete', [DestinationsController::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'flights'], function () {

        Route::middleware(['auth.rule:flights_show'])->group(function () {
            Route::get('/', [FlightsController::class, 'index']);
            Route::get('/print-parcels', [FlightsController::class, 'print_parcels']);
            Route::get('/{id}/print', [FlightsController::class, 'print_a4']);
            Route::get('/{id}/show', [FlightsController::class, 'show']);
            Route::get('/{id}/receive', [FlightsController::class, 'receive']);
        });
        Route::middleware(['auth.rule:flights_show_reports'])->group(function () {
            Route::get('/reports', [FlightsController::class, 'report']);
            Route::get('/reports/view', [FlightsController::class, 'report_show']);
        });
        Route::middleware(['auth.rule:flights_create'])->group(function () {
            Route::get('/new', [FlightsController::class, 'create']);
            Route::get('/new-v2', [FlightsController::class, 'create_v2']);
            Route::post('/store', [FlightsController::class, 'store']);
        });
        Route::middleware(['auth.rule:flights_edit'])->group(function () {
            Route::get('/{id}/edit', [FlightsController::class, 'edit']);
            Route::post('/{id}/update', [FlightsController::class, 'update']);
        });
        Route::middleware(['auth.rule:flights_delete'])->group(function () {
            Route::get('/{id}/delete', [FlightsController::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'receipts'], function () {
        Route::get('/', [ReceiptsController::class, 'index']);
        Route::get('/new', [ReceiptsController::class, 'create']);
        Route::post('/store', [ReceiptsController::class, 'store']);
        Route::get('/{id}/delete', [ReceiptsController::class, 'destroy']);
        Route::get('/{id}/edit', [ReceiptsController::class, 'edit']);
        Route::get('/{id}/print', [ReceiptsController::class, 'print_a4']);
        Route::post('/{id}/update', [ReceiptsController::class, 'update']);
        Route::get('/{id}/show', [ReceiptsController::class, 'show']);
    });
    Route::group(['prefix' => 'store-receipts'], function () {

        Route::middleware(['auth.rule:store_receipts_show'])->group(function () {
            Route::get('/', [StoreReceiptsController::class, 'index']);
            Route::get('/{id}/print', [StoreReceiptsController::class, 'print_a4']);
        });
        Route::middleware(['auth.rule:store_receipts_create'])->group(function () {
            Route::get('/new', [StoreReceiptsController::class, 'create']);
        });
        Route::middleware(['auth.rule:store_receipts_edit'])->group(function () {
            Route::get('/{id}/edit', [StoreReceiptsController::class, 'edit']);
        });
        Route::middleware(['auth.rule:store_receipts_delete'])->group(function () {
            Route::get('/{id}/delete', [StoreReceiptsController::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'store-request'], function () {
        Route::middleware(['auth.rule:store_request_show'])->group(function () {
            Route::get('/', [StoreReceiptRequest::class, 'index']);
            Route::get('/{id}/print', [StoreReceiptRequest::class, 'print_a4']);
        });
        Route::middleware(['auth.rule:store_request_create'])->group(function () {
            Route::get('/new', [StoreReceiptRequest::class, 'create']);
        });
        Route::middleware(['auth.rule:store_request_edit'])->group(function () {
            Route::get('/{id}/edit', [StoreReceiptRequest::class, 'edit']);
        });
        Route::middleware(['auth.rule:store_request_delete'])->group(function () {
            Route::get('/{id}/delete', [StoreReceiptRequest::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'store-return'], function () {
        Route::middleware(['auth.rule:store_return_show'])->group(function () {
            Route::get('/', [StoreReceiptReturn::class, 'index']);
            Route::get('/{id}/print', [StoreReceiptReturn::class, 'print_a4']);
            Route::get('/print', [StoreReceiptReturn::class, 'print_all']);
        });
        Route::middleware(['auth.rule:store_return_create'])->group(function () {
            Route::get('/new', [StoreReceiptReturn::class, 'create']);
        });
        Route::middleware(['auth.rule:store_return_delete'])->group(function () {
            Route::get('/{id}/delete', [StoreReceiptReturn::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'delivery-return'], function () {
        Route::middleware(['auth.rule:deliveryman_return_show'])->group(function () {
            Route::get('/', [DeliveryReceiptReturn::class, 'index']);
            Route::get('/{id}/print', [DeliveryReceiptReturn::class, 'print_a4']);
            Route::get('/print', [DeliveryReceiptReturn::class, 'print_all']);
        });
        Route::middleware(['auth.rule:deliveryman_return_create'])->group(function () {
            Route::get('/new', [DeliveryReceiptReturn::class, 'create']);
            Route::get('/new-v2', [DeliveryReceiptReturn::class, 'create_v2']);
        });
        Route::middleware(['auth.rule:deliveryman_return_delete'])->group(function () {
            Route::get('/{id}/delete', [DeliveryReceiptReturn::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'delivery-receipt'], function () {
        Route::middleware(['auth.rule:deliveryman_request_show'])->group(function () {
            Route::get('/', [DeliveryReceiptController::class, 'index']);
            Route::get('/{id}/print', [DeliveryReceiptController::class, 'print_a4']);
        });
        Route::middleware(['auth.rule:deliveryman_request_create'])->group(function () {
            Route::get('/new', [DeliveryReceiptController::class, 'create']);
            Route::get('/new-v2', [DeliveryReceiptController::class, 'create_v2']);
        });
        Route::middleware(['auth.rule:deliveryman_request_delete'])->group(function () {
            Route::get('/{id}/delete', [DeliveryReceiptController::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'collections-receipt'], function () {
        Route::middleware(['auth.rule:deliveryman_collections_receipt_show'])->group(function () {
            Route::get('/', [DeliveryCollectionsReceipt::class, 'index']);
            Route::get('/{id}/print', [DeliveryCollectionsReceipt::class, 'print_a4']);
        });
        Route::middleware(['auth.rule:deliveryman_collections_receipt_create'])->group(function () {
            Route::get('/new', [DeliveryCollectionsReceipt::class, 'create']);
        });
    });
    Route::group(['prefix' => 'delivery-receipts-cash'], function () {
        Route::middleware(['auth.rule:deliveryman_receipts_show'])->group(function () {
            Route::get('/', [DeliveryReceiptsCash::class, 'index']);
            Route::get('/{id}/print', [DeliveryReceiptsCash::class, 'print_a4']);
        });
        Route::middleware(['auth.rule:deliveryman_receipts_create'])->group(function () {
            Route::get('/new', [DeliveryReceiptsCash::class, 'create']);
        });
        Route::middleware(['auth.rule:deliveryman_receipts_delete'])->group(function () {
            Route::get('/{id}/delete', [DeliveryReceiptsCash::class, 'destroy']);
        });
    });
    Route::group(['prefix' => 'collections'], function () {

        Route::get('/', [CollectionsController::class, 'index']);
        Route::get('/{id}/show', [CollectionsController::class, 'show']);
        Route::get('/{id}/accept', [CollectionsController::class, 'accept']);

        Route::get('/{id}/print', [CollectionsController::class, 'print_a5']);
        Route::get('/print', [CollectionsController::class, 'print_all']);


        Route::middleware(['auth.rule:collections_flights_create'])->group(function () {
            Route::get('/new', [CollectionsController::class, 'create']);
        });

        Route::middleware(['auth.rule:collections_flights_show'])->group(function () {
            Route::group(['prefix' => 'flights'], function () {
                Route::get('/', [CollectionFlightController::class, 'index']);
                Route::get('/{id}/print', [CollectionFlightController::class, 'print_flight_list']);
                Route::get('/{id}/show', [CollectionFlightController::class, 'show']);
            });
        });
    });
    Route::group(['prefix' => 'treasuries', 'middleware' => ['auth.rule:treasury']], function () {
        Route::get('/', [TreasuryController::class, 'index']);
        Route::get('/new', [TreasuryController::class, 'create']);
        Route::post('/store', [TreasuryController::class, 'store']);
        Route::get('/{id}/edit', [TreasuryController::class, 'edit']);
        Route::get('/{id}/transactions', [TreasuryController::class, 'transactions_print']);
        Route::post('/{id}/update', [TreasuryController::class, 'update']);
    });
    Route::group(['prefix' => 'transactions', 'middleware' => ['auth.rule:treasury']], function () {
        Route::get('/', [TransactionController::class, 'index']);
        Route::get('/new', [TransactionController::class, 'create']);
        Route::post('/store', [TransactionController::class, 'store']);
        Route::get('/print/{id}', [TransactionController::class, 'print_a4']);
        Route::get('/destination-report', [TransactionController::class, 'destination_report']);
        Route::get('/{id}/delete', [TransactionController::class, 'destroy']);
    });
    Route::resource('store-transactions', StoreTransactionsController::class)->middleware('auth.rule:treasury');
    Route::group(['prefix' => 'store-transactions', 'middleware' => ['auth.rule:treasury']], function () {
        Route::get('/{id}/delete', [StoreTransactionsController::class, 'delete']);
    });
    Route::group(['prefix' => 'branch-flights', 'middleware' => ['auth.rule:flights_show']], function () {
        Route::get('/', [BranchFlightController::class, 'index']);
        Route::get('/new', [BranchFlightController::class, 'create']);
        Route::get('/new-v2', [BranchFlightController::class, 'create_v2']);
        Route::post('/store', [BranchFlightController::class, 'store']);
        Route::put('/{id}/assign', [BranchFlightController::class, 'assign']);
        Route::get('/{id}/print', [BranchFlightController::class, 'print_a4']);
        Route::get('/{id}/receive', [BranchFlightController::class, 'receive']);
        Route::post('/{id}/receive', [BranchFlightController::class, 'receive_store']);
        Route::post('/{id}/close-receive', [BranchFlightController::class, 'close_receive']);
        Route::get('/{id}/edit', [BranchFlightController::class, 'edit']);
        Route::post('/{id}/update', [BranchFlightController::class, 'update']);
        Route::post('/{id}/barcode-receive', [BranchFlightController::class, 'barcode_receive']);
    });
    Route::get('/in-office/parcel-info/{id}', [InOfficeDeliveryController::class, 'parcelInfo']);
    Route::resource('in-office', InOfficeDeliveryController::class);
    Route::group(['prefix' => 'branch-settlements', 'as' => 'branch-settlements.', 'middleware' => ['auth.rule:treasury']], function () {
        Route::post('/{branch_settlement}/accept', [BranchSettlementsController::class, 'accept'])->name('accept');
        Route::get('/dues', [BranchSettlementsController::class, 'dues'])->name('dues');
    });
    Route::resource('branch-settlements', BranchSettlementsController::class)->middleware('auth.rule:treasury');
    Route::resource('employee-transactions', EmployeeTransactionsController::class);
    Route::resource('payrolls', PayrollsController::class);
    Route::resource('salaries', SalariesController::class);
    Route::group(['prefix' => 'money-transfers', 'as' => 'money-transfers.'], function () {
        Route::get('/{money_transfer}/accept', [MoneyTransfersController::class, 'accept']);
    });
    Route::resource('money-transfers', MoneyTransfersController::class);
    Route::resource('transfer-settlements', TransferSettlementsController::class);
    Route::group(['prefix' => 'users', 'as' => 'users.'], function () {
        Route::get('/{id}/change-status', [UsersController::class, 'change_status']);
    });
    Route::resource('users', UsersController::class);
    Route::resource('custody', CustodyController::class);
    Route::resource('products', ProductsController::class);
    Route::get('/branches/my-branch', [BranchesController::class, 'my_branch']);
    Route::post('/branches/my-branch', [BranchesController::class, 'my_branch_update']);
    Route::resource('branches', BranchesController::class);
    Route::resource('store-cities', StoreCitiesController::class);
    Route::resource('galleries', GalleriesController::class);
    Route::get('/system-settings', [SystemSettingsController::class, 'index']);
    Route::post('/system-settings', [SystemSettingsController::class, 'update']);

    Route::group(['prefix' => 'tasks', 'as' => 'tasks.'], function () {
        Route::get('/', [UserTasksController::class, 'index'])->name('index');
        Route::get('/return-tasks', [UserTasksController::class, 'returnTasks'])->name('return');
        Route::get('/financial-tasks', [UserTasksController::class, 'financialTasks'])->name('financial');
        Route::post('/{type}/{id}/status', [UserTasksController::class, 'updateStatus'])
            ->where('type', 'tasks|return-tasks|financial-tasks')
            ->name('status');
    });

    Route::group(['prefix' => 'transfers', 'as' => 'transfers.'], function () {
        Route::get('/', [TransfersHubController::class, 'index'])->name('hub');
        Route::get('/settings', [TransfersHubController::class, 'settings'])->name('settings');
        Route::get('/price-list', [TransferPriceListController::class, 'catalog'])->name('price-list');

        $registerChatRoutes = function (string $controller) {
            Route::get('/', [$controller, 'index'])->name('index');
            Route::get('/unread-summary', [$controller, 'unreadSummary'])->name('unread-summary');
            Route::post('/broadcast-notice', [$controller, 'broadcastNotice'])->name('broadcast-notice');
            Route::post('/conversations/{conversation}/read', [$controller, 'markRead'])
                ->whereNumber('conversation')->name('read');
            Route::get('/conversation-with/{branchId}', [$controller, 'conversationWith'])
                ->whereNumber('branchId')->name('conversation-with');
            Route::get('/conversations/{conversation}/messages', [$controller, 'messages'])
                ->whereNumber('conversation')->name('messages');
            Route::post('/conversations/{conversation}/messages', [$controller, 'storeMessage'])
                ->whereNumber('conversation')->name('messages.store');
            Route::post('/conversations/{conversation}/settlement-message', [$controller, 'storeSettlementMessage'])
                ->whereNumber('conversation')->name('settlement');
            Route::post('/conversations/{conversation}/messages/{message}/execute', [$controller, 'executeMessage'])
                ->whereNumber('conversation')->whereNumber('message')->name('execute');
            Route::post('/conversations/{conversation}/messages/{message}/cancel', [$controller, 'cancelMessage'])
                ->whereNumber('conversation')->whereNumber('message')->name('cancel');
            Route::patch('/conversations/{conversation}/messages/{message}', [$controller, 'updateMessage'])
                ->whereNumber('conversation')->whereNumber('message')->name('update');
            Route::post('/conversations/{conversation}/messages/{message}/forward', [$controller, 'forwardMessage'])
                ->whereNumber('conversation')->whereNumber('message')->name('forward');
        };

        Route::group(['prefix' => 'internal-chat', 'as' => 'internal.'], function () use ($registerChatRoutes) {
            $registerChatRoutes(InternalTransferChatController::class);
        });

        Route::group(['prefix' => 'external-chat', 'as' => 'external.'], function () use ($registerChatRoutes) {
            $registerChatRoutes(ExternalTransferChatController::class);
        });

        Route::group(['prefix' => 'settings', 'as' => 'settings.'], function () {
            Route::get('/price-list', [TransferPriceListController::class, 'index'])->name('price-list');
            Route::post('/price-list/categories', [TransferPriceListController::class, 'storeCategory'])->name('price-list.categories.store');
            Route::post('/price-list/categories/{id}/items', [TransferPriceListController::class, 'storeItem'])
                ->whereNumber('id')->name('price-list.items.store');
            Route::post('/price-list/categories/{id}/delete', [TransferPriceListController::class, 'destroyCategory'])
                ->whereNumber('id')->name('price-list.categories.delete');
            Route::post('/price-list/items/{id}/delete', [TransferPriceListController::class, 'destroyItem'])
                ->whereNumber('id')->name('price-list.items.delete');
            Route::get('/internal', [TransfersBranchVisibilityController::class, 'internal'])->name('internal');
            Route::post('/internal', [TransfersBranchVisibilityController::class, 'updateInternal'])->name('internal.update');
            Route::get('/external', [TransfersBranchVisibilityController::class, 'external'])->name('external');
            Route::post('/external', [TransfersBranchVisibilityController::class, 'updateExternal'])->name('external.update');
        });
    });

});
