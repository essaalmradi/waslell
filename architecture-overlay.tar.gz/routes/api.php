<?php

use Illuminate\Support\Facades\Route;

require __DIR__ . '/api/legacy.php';

Route::prefix('clientarea')->name('clientarea.')->group(base_path('routes/api/clientarea.php'));
Route::prefix('v1')->name('v1.')->group(base_path('routes/api/v1.php'));

Route::fallback(function () {
    return response()->json([
        'errors' => ['عنوان الصفحة خاطئ'],
        'data' => [],
        'status_code' => 404,
    ], 404);
});
