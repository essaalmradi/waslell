<?php

require __DIR__ . '/web/public.php';
require __DIR__ . '/web/persons.php';
require __DIR__ . '/web/admin.php';
require __DIR__ . '/web/staff.php';
